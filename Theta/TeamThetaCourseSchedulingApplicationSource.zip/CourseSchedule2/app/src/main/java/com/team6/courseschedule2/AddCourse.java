package com.team6.courseschedule2;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class AddCourse extends ActionBarActivity {
    private EditText deptText, NumText;
    private Sched sched;
    private ListView CourseList;
    private ArrayList<Sched> scheduleList = new ArrayList<Sched>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);

        Intent i = getIntent();
        Sched sch = (Sched)i.getSerializableExtra("Sche");
        scheduleList = (ArrayList<Sched>) i.getSerializableExtra("SA");
        sched = sch;

        deptText   = (EditText)findViewById(R.id.DeptText);
        NumText   = (EditText)findViewById(R.id.NumText);
        CourseList  = (ListView)findViewById(R.id.CourseList);

        refresh();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_course, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void SearchButtonOnClick (View v) {
        String dept = deptText.getText().toString();
        int num = Integer.parseInt(NumText.getText().toString());

        Intent i = new Intent(AddCourse.this, SearchedCourses.class);
        i.putExtra("Sche", sched);
        i.putExtra("dept", dept);
        i.putExtra("num", num);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void returnButtonOnClick(View v){
        Intent i = new Intent(AddCourse.this, modifySchedule.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void addButtonOnClick(View v){
        String dept = deptText.getText().toString();
        int num = Integer.parseInt(NumText.getText().toString());

        Courses m = new Courses(dept, num, 0, 0);
        sched.addCourses(m);

        Intent i = new Intent(AddCourse.this, modifySchedule.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void refresh(){
        ArrayList<String> courses = new ArrayList<String>();
        populate(courses);

        String[] courseArray = courses.toArray(new String[courses.size()]);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.list_items, courseArray);
        CourseList.setAdapter(adapter);
    }

    public void populate(ArrayList<String> c){
        ArrayList<Courses> cors = sched.getCourses();
        String tbs;
        for(Courses m: cors){
            tbs = "";
            tbs += m.getDept() + " " + m.getNum();
            c.add(tbs);
        }
    }

    @Override
    public void onBackPressed() {
    }
}
