package com.team6.courseschedule2;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


public class schedule extends ActionBarActivity {

    EditText scheduleName = null;
    private ArrayList<Sched> scheduleList = new ArrayList<Sched>();
    //Button input
    private Button mButton;
    private EditText mEdit;
    private String schedname;
    private ArrayAdapter<String> adapter;
    private ListView schedList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);


        Intent i = getIntent();
        if(i.hasExtra("Sche")) {
            Sched sch = (Sched) i.getSerializableExtra("Sche");
            scheduleList = (ArrayList<Sched>) i.getSerializableExtra("SA");

            /*if (!scheduleList.contains(sch)) {
                scheduleList.add(sch);
            }*/
        }

        //to get user input from text
        mButton = (Button)findViewById(R.id.CreateScheduleButton);
        mEdit   = (EditText)findViewById(R.id.createScheduleButton);
        schedList = (ListView)findViewById(R.id.schedList);

        refresh();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_schedule, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void createScheduleButtonOnClick(View v) {
            Intent modify = new Intent(schedule.this, modifySchedule.class);
            //Have text as new schedule name
            Sched newSched = new Sched(mEdit.getText().toString());
            /*Test
            //Courses cor = new Courses("CSE", 3310, 1045, 1050);
            //newSched.addCourses(cor);

            for(int i = 0; i<5; i++){
                newSched.addTimeBlocks(new TBlocks(0,0));
            }
            TEST*/
            scheduleList.add(newSched);
            //serialize and create new Activity
            modify.putExtra("Sche", newSched);
            modify.putExtra("SA", scheduleList);
            startActivity(modify);
    }

    public void returnButtonOnClick(View v){
        Intent i = new Intent(schedule.this, main_menu.class);
        startActivity(i);
    }

    @Override
    public void onBackPressed() {
    }

    public void refresh(){
        ArrayList<String> scheds = new ArrayList<String>();
        populate(scheds);

        String[] sArray = scheds.toArray(new String[scheds.size()]);

        adapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.list_items, sArray);
        schedList.setAdapter(adapter);
    }

    public void populate(ArrayList<String> c){
        String tbs;
        for(Sched s: scheduleList){
            tbs = "";
            tbs = s.getName();
            c.add(tbs);
        }
    }

}
