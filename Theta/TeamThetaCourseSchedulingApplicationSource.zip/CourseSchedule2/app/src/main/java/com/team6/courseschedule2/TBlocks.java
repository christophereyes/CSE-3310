package com.team6.courseschedule2;

import java.io.Serializable;
import java.sql.Time;

/**
 * Created by Orion on 5/6/2015.
 */
public class TBlocks implements Serializable {
    private int start;
    private int end;

    public TBlocks(){
        start = 0;
        end = 0;
    }

    public TBlocks(int s, int e){
        start = s;
        end = e;
    }

    public int getStart(){
        return start;
    }

    public int getEnd(){
        return end;
    }

    public boolean compare(TBlocks tblock){
        if((tblock.getStart() == start) && (tblock.getEnd() == end)){
            return true;
        }
        return false;
    }
}