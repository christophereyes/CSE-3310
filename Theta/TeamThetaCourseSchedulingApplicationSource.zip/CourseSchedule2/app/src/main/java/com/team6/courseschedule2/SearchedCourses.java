package com.team6.courseschedule2;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.view.KeyEvent;

import java.util.ArrayList;


public class SearchedCourses extends Activity {
    private Sched sched;
    private String dept;
    private int num;
    private ListView CourseList;
    private ArrayList<Sched> scheduleList = new ArrayList<Sched>();
    private ArrayList<Courses> courses;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searched_courses);

        Intent i = getIntent();
        Sched sch = (Sched)i.getSerializableExtra("Sche");
        scheduleList = (ArrayList<Sched>)i.getSerializableExtra("SA");
        sched = sch;

        dept   = (String)i.getSerializableExtra("dept");
        num   = (int)i.getSerializableExtra("num");

        CourseList  = (ListView)findViewById(R.id.CourseList);
        CourseList.setClickable(true);

        populating();
        refresh();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_searched_courses, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void returnButtonOnClick(View v){
        Intent i = new Intent(SearchedCourses.this, AddCourse.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void refresh(){
        ArrayList<String> courses = new ArrayList<String>();
        populate(courses, dept, num);

        String[] courseArray = courses.toArray(new String[courses.size()]);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.list_items, courseArray);
        CourseList.setAdapter(adapter);
    }

    public void populate(ArrayList<String> c, String dep, int numb){
        ArrayList<Courses> cors = courses;
        String tbs;
        for(Courses m: cors){
            if(m.getDept().equals(dept) && m.getNum() == num){
                tbs = "";
                tbs += m.getDept() + " " + m.getNum() + ": " + m.getStartCourse() + " - " + m.getEndCourse();
                c.add(tbs);
            }
        }
    }

    public void populating(){
        ArrayList<Courses> cors = new ArrayList<Courses>();

        Courses newCourse = new Courses("CSE", 1311, 1030, 1150);
        Courses newCourse2 = new Courses("CSE", 1320, 1130, 1250);
        Courses newCourse3 = new Courses("CSE", 1325, 1330, 1450);
        Courses newCourse4 = new Courses("CSE", 1325, 1030, 1150);
        Courses newCourse5 = new Courses("CSE", 3311, 1030, 1150);
        Courses newCourse6 = new Courses("CSE", 2320, 1330, 1450);
        Courses newCourse7 = new Courses("CSE", 2320, 1030, 1150);
        Courses newCourse8 = new Courses("CSE", 3320, 1030, 1150);
        Courses newCourse9 = new Courses("CSE", 1311, 1730, 1850);
        Courses newCourse10 = new Courses("CSE", 1311, 1400, 1350);

        cors.add(newCourse);
        cors.add(newCourse2);
        cors.add(newCourse3);
        cors.add(newCourse4);
        cors.add(newCourse5);
        cors.add(newCourse6);
        cors.add(newCourse7);
        cors.add(newCourse8);
        cors.add(newCourse9);
        cors.add(newCourse10);

        courses = cors;
    }

    @Override
    public void onBackPressed() {
    }
}
