package com.team6.courseschedule2;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


public class Timeblocks extends ActionBarActivity {
    private EditText startTime;
    private EditText endTime;
    private ListView TbList;
    private ArrayAdapter<String> adapter;
    private ArrayList<Sched> scheduleList = new ArrayList<Sched>();
    private Sched sched;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timeblocks);

        Intent i = getIntent();
        Sched sch = (Sched)i.getSerializableExtra("Sche");
        scheduleList = (ArrayList<Sched>) i.getSerializableExtra("SA");
        sched = sch;

        startTime = (EditText)findViewById(R.id.startTimeText);
        endTime   = (EditText)findViewById(R.id.endTimeText);
        TbList    = (ListView)findViewById(R.id.TbList);

        refresh();

        /*ArrayList<String> tblocks = new ArrayList<String>();
        populate(tblocks);

        String[] tbArray = tblocks.toArray(new String[tblocks.size()]);

        adapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.list_items, tbArray);
        TbList.setAdapter(adapter);*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_timeblocks, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void addTimeblockButtonOnClick(View v) {
        int start = Integer.parseInt(startTime.getText().toString());
        int end = Integer.parseInt(endTime.getText().toString());

        TBlocks tb = new TBlocks(start, end);
        //sched.addTimeBlocks(tb);

        if(start<2360 && end <2360){
            if(((start%100) - 59 <= 0) && ((end%100) - 59 <= 0)){
                if(start < end){
                    sched.addTimeBlocks(tb);
                }
            }
        }

        refresh();
    }

    public void returnButtonOnClick(View v){
        Intent i = new Intent(Timeblocks.this, modifySchedule.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void populate(ArrayList<String> c){
        ArrayList<TBlocks> tb = sched.getTimeBlocks();
        String tbs;
        for(TBlocks m: tb){
            tbs = "";
            tbs += m.getStart() + " - " + m.getEnd();
            c.add(tbs);
        }
    }

    public void refresh(){
        ArrayList<String> tblocks = new ArrayList<String>();
        populate(tblocks);

        String[] tbArray = tblocks.toArray(new String[tblocks.size()]);

        adapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.list_items, tbArray);
        TbList.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
    }
}
