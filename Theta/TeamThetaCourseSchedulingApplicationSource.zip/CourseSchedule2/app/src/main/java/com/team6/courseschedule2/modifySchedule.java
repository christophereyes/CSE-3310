package com.team6.courseschedule2;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class modifySchedule extends ActionBarActivity {

    private Sched sched;
    private TextView SchedName;
    private ListView CourseList;
    private ArrayList<Sched> scheduleList = new ArrayList<Sched>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_schedule);

        //Input serialized schedule
        Intent i = getIntent();
        Sched sch = (Sched)i.getSerializableExtra("Sche");
        scheduleList = (ArrayList<Sched>) i.getSerializableExtra("SA");
        setSchedule(sch);

        ArrayList<String> courses = new ArrayList<String>();
        populate(courses);

        String[] courseArray = courses.toArray(new String[courses.size()]);

        //String[] courseArray = {"one","two","three"};

        SchedName   = (TextView)findViewById(R.id.SchedName);
        SchedName.setText(sch.getName());
        CourseList  = (ListView)findViewById(R.id.CourseList);

        //ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, courseArray);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(), R.layout.list_items, courseArray);
        CourseList.setAdapter(adapter);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_modify_schedule, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void addCourseButtonOnClick(View v) {
        Intent i = new Intent(modifySchedule.this, AddCourse.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void deleteCourseButtonOnClick(View v) {
        Intent i = new Intent(modifySchedule.this, DeleteCourse.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void timeblockButtonOnClick(View v) {
        Intent i = new Intent(modifySchedule.this, Timeblocks.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    public void deleteScheduleButtonOnClick(View v) {
        //add
    }

    public void setSchedule(Sched sch){
        sched = sch;
    }

    public void populate(ArrayList<String> c){
        ArrayList<Courses> cours = sched.getCourses();
        String crs;
        for(Courses m: cours){
            crs = "";
            crs += m.getDept() + " " + m.getNum();
            c.add(crs);
        }
    }

    public void returnButtonOnClick(View v){
        Intent i = new Intent(modifySchedule.this, schedule.class);
        i.putExtra("Sche", sched);
        i.putExtra("SA", scheduleList);
        startActivity(i);
    }

    @Override
    public void onBackPressed() {
    }
}
