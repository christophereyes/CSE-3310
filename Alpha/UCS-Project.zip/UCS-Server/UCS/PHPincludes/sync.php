<?php

/*	This page syncs user data to the database
 *
 */
	include_once 'db_connect.php';
	include_once 'functions.php';

	sec_session_start();

	$error_messages = []; 
	$success_messages = [];
	$result = [];

	if (login_check($mysqli) == true){


		//echo json_encode($post_data);
		if(isset($_SESSION['user_id'])){


			$scheduleCount = 0;
			$scheduleUpdate = 0;
			if(isset($_POST['SCHEDULES'])){
				$scheduleJSON = json_decode($_POST['SCHEDULES'], true);
				foreach ($scheduleJSON as $schedule_data) {
					//echo '<p>'.json_encode($schedule_data).'</p>'; 
					if(isset($schedule_data['ScheduleID'])){
						//Schedule already has a scheduleID, which indicates it already exists in the database and should be updated rather than added as a new schedule
						$ScheduleID = $schedule_data['ScheduleID'];
						unset($schedule_data['ScheduleID']);
						//echo '<p>'.json_encode($schedule_data).'<p>';
						if ($stmt = $mysqli->prepare("UPDATE schedules SET schedules.ScheduleString = ? 
							WHERE schedules.ScheduleID = ?
							LIMIT 1")) {
								$stmt->bind_param('ss', json_encode($schedule_data), $ScheduleID);  // Bind to parameters.
								$stmt->execute();    // Execute the prepared query.
								$success_messages[] = 'updated schedule with scheduleID of:'.$ScheduleID;                                                                                                                                                                               
						}
						$scheduleUpdate = $scheduleUpdate + 1;
					} else {
						if ($stmt = $mysqli->prepare("INSERT INTO schedules (AccountID, ScheduleString) VALUES (?, ?)")) {
								$stmt->bind_param('ss', $_SESSION['user_id'], json_encode($schedule_data));  // Bind to parameters.
								$stmt->execute();    // Execute the prepared query.
						}
					}
					$scheduleCount = $scheduleCount + 1;
				}
				$success_messages[] = $scheduleCount.' schedules, of which '.$scheduleUpdate.' are updates.';
			}
			else{
				$error_messages[] = 'No Schedule Data Found';
			}


			$blockoutCount = 0;
			$blockoutUpdate = 0;
			if(isset($_POST['BLOCKOUTTIMES'])){
				$blockoutJSON = json_decode($_POST['BLOCKOUTTIMES'], true);
				foreach ($blockoutJSON as $blockout_data) {
					if(isset($blockout_data['BlockOutTimeID'])){
						$BlockOutTimeID = $blockout_data['BlockOutTimeID'];
						unset($blockout_data['BlockOutTimeID']);
						if ($stmt = $mysqli->prepare("UPDATE blockout_times SET blockout_times.BlockOutString = ? 
							WHERE blockout_times.BlockOutID = ?
							LIMIT 1")) {
								$stmt->bind_param('ss', json_encode($blockout_data), $BlockOutTimeID);  // Bind to parameters.
								$stmt->execute();    // Execute the prepared query.
						}
						$blockoutUpdate = $blockoutUpdate + 1;
					} else {
						if ($stmt = $mysqli->prepare("INSERT INTO blockout_times (AccountID, BlockOutString) VALUES (?, ?)")) {
								$stmt->bind_param('ss', $_SESSION['user_id'], json_encode($blockout_data));  // Bind to parameters.
								$stmt->execute();    // Execute the prepared query.
						}
					}
					$blockoutCount = $blockoutCount + 1;
				}
				$success_messages[] = $blockoutCount.' blockout times, of which '.$blockoutUpdate.' are updates.';
			}
			else{
				$error_messages[] = 'No BlockOut Data Found';
			}

			if(isset($_POST['MilitaryTime'])){

				if ($stmt = $mysqli->prepare("INSERT INTO member_settings
								 (AccountID, MilitaryTime)
								 VALUES (?, ?)
								 ON DUPLICATE KEY
								 UPDATE
								 MilitaryTime = VALUES(MilitaryTime)")) {
						$stmt->bind_param('ss', $_SESSION['user_id'], $_POST['MilitaryTime']);  // Bind to parameters.
						$stmt->execute();    // Execute the prepared query.
				}
			}
			else {
				$error_messages[] = 'No MilitaryTime Setting found';
			}

		} else {
			$error_messages[] = 'No UserID found. Please login before attempting to retrieve saved info.';
		}
	} else {
		$error_messages[] = 'Not Logged In. Please login before attempting to retrieve saved info.';
	}

	if (empty($error_messages)){
		$result['SUCCESS'] = true;
		$result['MESSAGES'] = $success_messages;
	} else {
		$result['ERRORS'] = $error_messages;
		$result['SUCCESS'] = false;
	}

	echo json_encode($result);
?>
