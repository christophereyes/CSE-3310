Written by Arun Kalahasti
Email: arun.kalahasti@mavs.uta.edu

This package is designed to be deployed on a standard LAMP stack with python 3.
Copying the contents of this folder to the /var/www/html folder after the LAMP stack is deployed should get you started.
Make sure you update the URL used in the applications. Android URLs are located in UCS-Android_App\app\src\main\res\values\url.xml
Note: The UCS folder itself is expected to be within the html folder, not just its contents.

Developed on Ubuntu 15.04 x86 32-bit, but any os with support for Apache v2.4 or later, mySQL 4.1.3 or later, PHP server 5.3 or later, and Python 3.3 or later should work fine.
For help setting up mySQL for use with this software package refer to: http://www.wikihow.com/Create-a-Secure-Login-Script-in-PHP-and-MySQL

Python and python package versions used during development:
Python 3.3 & 3.4
BeautifulSoup4 4.4.0
Requests 2.7.0